package br.com.fila.teste;

import br.com.fila.Fila;
import br.com.menu.Menu;

public class Teste {

	public static void main(String[] args) {
		
		Menu m = new Menu();
		m.Visao_Operador();

	}

}