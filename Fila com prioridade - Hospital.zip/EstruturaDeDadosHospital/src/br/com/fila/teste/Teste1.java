package br.com.fila.teste;

public class Teste1 {

	public static void main(String[] args) {
		String a = "[Medicos [nome=joao, crm=123456, especialidade=Cardiologista, usuario=joao123, senha=123]]";
		String[] b = a.split(", crm=");
		String[] c = b[0].split("nome=");
		
		System.out.println(a);
		System.out.println("\n\n");
		System.out.println(b[0]);
		System.out.println(b[1]);
		System.out.println(c[0]);
		System.out.println(c[1]);
	}

}
