package br.com.construtores;

public class Pacientes {
	
	private String nome;
	private float temperatura;
	private float pressao;
	private String email;
	private String condicao;
	private String sintomas;
	
	public Pacientes(String pnome, float ptemperatura, float ppressao, String pemail, String pcondicao, String psintomas) {
		this.nome = pnome;
		this.temperatura = ptemperatura;
		this.pressao = ppressao;
		this.email = pemail;
		this.condicao = pcondicao;
		this.sintomas = psintomas;
	}

	@Override
	public String toString() {
		return "Pacientes [nome=" + nome + ", temperatura=" + temperatura + ", pressao=" + pressao + ", email=" + email
				+ ", condicao=" + condicao + ", sintomas=" + sintomas + "]";
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public float getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(float temperatura) {
		this.temperatura = temperatura;
	}

	public float getPressao() {
		return pressao;
	}

	public void setPressao(float pressao) {
		this.pressao = pressao;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCondicao() {
		return condicao;
	}

	public void setCondicao(String condicao) {
		this.condicao = condicao;
	}

	public String getSintomas() {
		return sintomas;
	}

	public void setSintomas(String sintomas) {
		this.sintomas = sintomas;
	}

}
