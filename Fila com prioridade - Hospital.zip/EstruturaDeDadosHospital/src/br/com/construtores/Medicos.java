package br.com.construtores;

public class Medicos {
	
	private String nome;
	private int crm;
	private String especialidade;
	private String usuario;
	private String senha;
	
	public Medicos(String pnome, int pcrm, String pespecialidade, String pusuario, String psenha) {
		this.nome = pnome;
		this.crm = pcrm;
		this.especialidade = pespecialidade;
		this.usuario = pusuario;
		this.senha = psenha;
	}

	@Override
	public String toString() {
		return "Medicos [nome=" + nome + ", crm=" + crm + ", especialidade=" + especialidade + ", usuario=" + usuario
				+ ", senha=" + senha + "]";
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCrm() {
		return crm;
	}

	public void setCrm(int crm) {
		this.crm = crm;
	}

	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

}
