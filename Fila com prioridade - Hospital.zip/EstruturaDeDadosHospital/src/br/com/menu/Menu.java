package br.com.menu;

import java.util.Scanner;

import javax.swing.JOptionPane;

import br.com.construtores.Medicos;
import br.com.construtores.Pacientes;
import br.com.fila.Fila;

public class Menu {

	Scanner sc = new Scanner(System.in);
	Scanner sc1 = new Scanner(System.in);
	Scanner sc2 = new Scanner(System.in);
	Scanner sc3 = new Scanner(System.in);
	
	Fila pacientes_AZUL = new Fila();
	Fila pacientes_VERDE = new Fila();
	Fila pacientes_AMARELO = new Fila();
	Fila pacientes_VERMELHO = new Fila();
	
	Fila pacientes = new Fila();
	Fila medicos = new Fila();

	public void Visao_Operador() {
		
		int opcao = 0;

		System.out.println("\n\t| 1 - Cadastrar paciente");
		System.out.println("\t| 2 - Cadastrar M�dico");
		System.out.println("\t| 3 - Login M�dico");
		System.out.println("\t| 4 - SAIR!");
		System.out.println(" - Selecione uma op��o v�lida:");
		opcao = sc1.nextInt();

		switch (opcao) {
		case 1:

			cad_Paciente();
			
			break;

		case 2:
			
			cad_Medico();

			break;

		case 3:
			
			login();
			
			break;

		case 4:

			System.out.println("\n\nSistema Encerrado com sucesso!!!");
			
			sc.close();
			sc1.close();
			sc2.close();
			sc3.close();
			System.exit(0);
			//break;

		default:
			System.out.println("\nVoc� inseriu uma op��o n�o v�lida!\n\n");
			Visao_Operador();
			
			break;

		}

		// sc.close();
	}

	public void cad_Paciente() {
		int opc_condicao = 0;
		String nome, email, condicao = null, sintomas;
		float temperatura, pressao;
		
		System.out.println("\nInforme os dados do paciente a ser cadastrado corretamente:\n");
		System.out.println("Na parte de CONDI��O, preencher com uma das op��es abaixo:");
		System.out.println("\t| 1 - AZUL");
		System.out.println("\t| 2 - VERDE");
		System.out.println("\t| 3 - AMARELO");
		System.out.println("\t| 4 - VERMELHO!");
		
		System.out.println("Nome:");
		nome = sc3.next();
		System.out.println("Temeperatura:");
		temperatura = sc3.nextFloat();
		System.out.println("Press�o:");
		pressao = sc3.nextFloat();
		System.out.println("E-mail:");
		email = sc3.next();
		System.out.println("Sintomas:");
		sintomas = sc3.next();
		
		System.out.println("Condi��o:");
		opc_condicao = sc3.nextInt();
		
		switch (opc_condicao) {
		case 1:

			condicao = "AZUL";
			
			break;

		case 2:
			
			condicao = "VERDE";

			break;

		case 3:
			
			condicao = "AMARELO";
			
			break;

		case 4:

			condicao = "VERMELHO";
			
			break;

		default:
			System.out.println("\nOp��o n�o v�lida, escolha 1,2,3 ou 4");
			cad_Paciente();
			
			break;

		}
		
		Pacientes p = new Pacientes(nome, temperatura, pressao, email, condicao, sintomas);
		//pacientes.enfileira(p);
		
		if(condicao.equals("AZUL")) {
			pacientes_AZUL.enfileira(p);
		}else if(condicao.equals("VERDE")) {
			pacientes_VERDE.enfileira(p);
		}else if(condicao.equals("AMARELO")) {
			pacientes_AMARELO.enfileira(p);
		}else if(condicao.equals("VERMELHO")) {
			pacientes_VERMELHO.enfileira(p);
		}
		
		pacientes.limpaFila();
		
		for(int i = 0; i < pacientes_VERMELHO.tamanho(); i++) {
			pacientes.enfileira(pacientes_VERMELHO.busca(i));
		}
		for(int i = 0; i < pacientes_AMARELO.tamanho(); i++) {
			pacientes.enfileira(pacientes_AMARELO.busca(i));
		}
		for(int i = 0; i < pacientes_VERDE.tamanho(); i++) {
			pacientes.enfileira(pacientes_VERDE.busca(i));
		}
		for(int i = 0; i < pacientes_AZUL.tamanho(); i++) {
			pacientes.enfileira(pacientes_AZUL.busca(i));
		}
		
		System.out.println(pacientes.toString());

		Visao_Operador();
	}

	public void cad_Medico() {

		String nome, especialidade, usuario, senha;
		int crm;

		System.out.println("\nInforme os dados do Dr. a ser cadastrado: ");
		System.out.println("Nome:");
		nome = sc.next();
		System.out.println("CRM:");
		crm = sc.nextInt();
		System.out.println("Especialidade:");
		especialidade = sc.next();
		System.out.println("Usuario:");
		usuario = sc.next();
		System.out.println("Senha:");
		senha = sc.next();

		Medicos dr = new Medicos(nome, crm, especialidade, usuario, senha);
		medicos.enfileira(dr);
		
		System.out.println(medicos.toString());

		Visao_Operador();
	}
	
	public void login() {

		String usuario, senha;
		String a, a1;
		String[] b, b1;
		String[] c = null, c1 = null;

		System.out.println("Informe o usuario:");
		usuario = sc.next();

		System.out.println("Informe a senha:");
		senha = sc.next();
		
		for(int i = 0; i < medicos.tamanho(); i++) {
			
			a = medicos.busca(i).toString();
			b = a.split("usuario=");
			c = b[1].split(", senha=");
			
			a1 = medicos.busca(i).toString();
			b1 = a1.split("usuario=");
			c1 = b1[1].split(", senha=");
			
			System.out.println(medicos.tamanho());
			
			if((usuario.equals(c[0])) && (senha.equals(c1[0]))) {
				System.out.println("usuario recolhecido com sucesso!\n\n");
				Visao_Medico();
			}
		}
		
		System.out.println("\nUsuario e/ou senha incorretos!");
		
		Visao_Operador();

	}

	public void Visao_Medico() {
		int opcao = 0;

		System.out.println("\n\t| 1 - Chamar Paciente");
		System.out.println("\t| 2 - Imprimir fila de Pacientes");
		System.out.println("\t| 3 - Ir p/ tela de vis�o do operador");
		System.out.println(" - Selecione uma op��o v�lida:");
		opcao = sc2.nextInt();

		switch (opcao) {
		case 1:
			
			String a;
			String[] b, c = null;
			
			if(pacientes.estaVazia()) {
				System.out.println("N�o h� pacientes na fila...");
				Visao_Medico();
			}
			
			a = pacientes.espiar().toString();
			b = a.split(", temperatura=");
			c = b[0].split("nome=");
			
			System.out.println("\nFoi chamado o paciente " + c[1]);
			pacientes.desinfileira();
			
			Visao_Medico();
			break;

		case 2:
			
			for(int i = 0; i < pacientes.tamanho(); i++) {
				System.out.println(pacientes.busca(i).toString());
			}
			Visao_Medico();
			break;

		case 3:
			
			Visao_Operador();

			break;

		default:
			System.out.println("\nVoc� inseriu uma op��o n�o v�lida!\n\n");
			Visao_Medico();

			break;

		}
	}
}
